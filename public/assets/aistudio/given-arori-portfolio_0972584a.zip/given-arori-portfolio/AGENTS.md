<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep portfolio copy and repeated content in `src/components/portfolio/content.ts` so contact and profile facts have one source of truth.
- Build the single-page portfolio from focused sections in `src/components/portfolio/Portfolio.tsx` because all navigation is anchored within the home experience.
