import { createFileRoute } from "@tanstack/react-router";
import { Portfolio } from "@/components/portfolio/Portfolio";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Given Arori — AI Solutions Specialist" },
      { name: "description", content: "Given Arori builds AI solutions, websites, apps, automation, and scalable systems for businesses." },
      { property: "og:title", content: "Given Arori — AI Solutions Specialist" },
      { property: "og:description", content: "AI solutions, websites, apps, automation, and scalable systems for businesses." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return <Portfolio />;
}
