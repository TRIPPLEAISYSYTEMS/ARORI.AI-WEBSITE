import { QueryClient } from "@tanstack/react-query";
import { createRouter, rootRouteId } from "@tanstack/react-router";
import { describe, expect, it } from "vitest";

import { routeTree } from "@/routeTree.gen";
import { profile, technologyRows } from "@/components/portfolio/content";

// Match routes without running loaders or rendering: loaders may need a server or
// network the test run lacks, and jsdom never loads the stylesheets React waits on.
describe("App routing", () => {
  it("matches a page for / instead of falling back to not found", () => {
    const router = createRouter({ routeTree, context: { queryClient: new QueryClient() } });

    const matches = router.matchRoutes("/");

    expect(matches.at(-1)?.routeId).not.toBe(rootRouteId);
  });
});

describe("Given Arori portfolio content", () => {
  it("uses the exact fourth-year education and contact details", () => {
    expect(profile.education).toBe(
      "Fourth-year B.Ed Science (Mathematics & Physics), Kenyatta University.",
    );
    expect(profile.phone).toBe("0792 767 922");
    expect(profile.whatsapp).toBe("https://wa.me/254792767922");
    expect(profile.linkedin).toBe("https://www.linkedin.com/in/arori/");
  });

  it("keeps a 100-item technology showcase", () => {
    expect(technologyRows.flat()).toHaveLength(100);
  });

  it("does not restore rejected positioning language", () => {
    expect(JSON.stringify(profile).toLowerCase()).not.toMatch(/visionary|technological empire/);
  });
});
