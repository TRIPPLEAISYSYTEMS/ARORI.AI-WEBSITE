import {
  ArrowDownRight,
  ArrowUpRight,
  Check,
  GraduationCap,
  Layers3,
  Linkedin,
  Menu,
  MessageCircle,
  Sparkles,
  X,
} from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";

import glassVisual from "@/assets/given-arori-ai-glass.jpg";
import { Button } from "@/components/ui/button";

import { StarField } from "./StarField";
import { navigation, profile, services, technologyRows } from "./content";

function ExternalLink({ href, children }: { href: string; children: ReactNode }) {
  return (
    <a href={href} target="_blank" rel="noreferrer" className="inline-link">
      {children}
      <ArrowUpRight aria-hidden="true" />
    </a>
  );
}

function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="fixed inset-x-0 top-0 z-50 px-4 pt-4 md:px-8">
      <div className="glass-nav mx-auto flex max-w-7xl items-center justify-between px-4 py-3 md:px-5">
        <a href="#top" className="font-display text-sm font-semibold text-foreground" aria-label="Given Arori, home">
          GIVEN / ARORI
        </a>
        <nav className="hidden items-center gap-6 lg:flex" aria-label="Primary navigation">
          {navigation.map((item) => (
            <a key={item.href} href={item.href} className="nav-link">
              {item.label}
            </a>
          ))}
        </nav>
        <div className="hidden lg:block">
          <Button asChild size="sm">
            <a href={profile.whatsapp} target="_blank" rel="noreferrer">
              <MessageCircle /> Chat on WhatsApp
            </a>
          </Button>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="lg:hidden"
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          onClick={() => setOpen((current) => !current)}
        >
          {open ? <X /> : <Menu />}
        </Button>
      </div>
      {open ? (
        <nav className="glass-nav mx-auto mt-2 grid max-w-7xl gap-1 p-3 lg:hidden" aria-label="Mobile navigation">
          {navigation.map((item) => (
            <a key={item.href} href={item.href} className="mobile-nav-link" onClick={() => setOpen(false)}>
              {item.label}
            </a>
          ))}
          <Button asChild className="mt-2 w-full">
            <a href={profile.whatsapp} target="_blank" rel="noreferrer">
              <MessageCircle /> Chat on WhatsApp
            </a>
          </Button>
        </nav>
      ) : null}
    </header>
  );
}

function Hero() {
  return (
    <section id="top" className="relative flex min-h-[92svh] items-end overflow-hidden px-5 pb-12 pt-32 md:px-10 md:pb-16">
      <div className="mx-auto grid w-full max-w-7xl items-end gap-12 lg:grid-cols-[1.05fr_0.95fr]">
        <div className="relative z-10 max-w-3xl animate-rise">
          <p className="eyebrow"><span className="status-dot" /> Available for ambitious builds</p>
          <h1 className="mt-6 font-display text-[clamp(3.5rem,9vw,8.5rem)] font-semibold leading-[0.88] text-foreground">
            Given<br /><span className="text-primary">Arori.</span>
          </h1>
          <p className="mt-8 max-w-2xl text-lg leading-8 text-muted-foreground md:text-xl">
            {profile.intro}
          </p>
          <div className="mt-9 flex flex-wrap gap-3">
            <Button asChild size="lg">
              <a href={profile.whatsapp} target="_blank" rel="noreferrer"><MessageCircle /> Chat on WhatsApp</a>
            </Button>
            <Button asChild size="lg" variant="glass">
              <a href="#oculus">View Oculus <ArrowDownRight /></a>
            </Button>
          </div>
        </div>
        <div className="hero-visual animate-rise-delayed" aria-hidden="true">
          <img src={glassVisual} alt="" width={1400} height={1050} className="h-full w-full object-cover" />
          <div className="hero-visual-label glass-panel">
            <span>AI / AUTOMATION / SYSTEMS</span>
            <span>NAIROBI, KE</span>
          </div>
        </div>
      </div>
    </section>
  );
}

function SectionHeading({ number, label, title }: { number: string; label: string; title: string }) {
  return (
    <div className="section-heading">
      <p className="eyebrow">{number} / {label}</p>
      <h2 className="mt-5 max-w-4xl font-display text-4xl font-semibold leading-tight text-foreground md:text-6xl">{title}</h2>
    </div>
  );
}

function About() {
  return (
    <section id="about" className="section-shell border-y border-border">
      <SectionHeading number="01" label="About" title="Curious by nature. Practical by design." />
      <div className="mt-14 grid gap-12 lg:grid-cols-2 lg:gap-20">
        <p className="text-balance font-display text-2xl leading-relaxed text-foreground md:text-3xl">
          I work where emerging AI meets useful business systems—testing what is possible, then shaping it into something people can actually use.
        </p>
        <div className="space-y-5 text-base leading-7 text-muted-foreground">
          <div className="glass-panel flex gap-4 p-5">
            <GraduationCap className="mt-1 size-5 shrink-0 text-primary" aria-hidden="true" />
            <div><p className="text-xs font-semibold uppercase text-foreground">Education</p><p className="mt-2">{profile.education}</p></div>
          </div>
          <div className="glass-panel flex gap-4 p-5">
            <Layers3 className="mt-1 size-5 shrink-0 text-primary" aria-hidden="true" />
            <div><p className="text-xs font-semibold uppercase text-foreground">Company</p><p className="mt-2">Building AI-powered work through <ExternalLink href={profile.company}>Tripple AI Systems</ExternalLink>.</p></div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Services() {
  return (
    <section id="services" className="section-shell">
      <SectionHeading number="02" label="Services" title="Digital capability, connected end to end." />
      <div className="mt-14 grid gap-px overflow-hidden rounded-lg border border-border bg-border sm:grid-cols-2 lg:grid-cols-4">
        {services.map(({ title, detail, icon: Icon }, index) => (
          <article key={title} className="service-item group bg-background/70 backdrop-blur-sm p-6 md:min-h-72">
            <div className="flex items-start justify-between"><Icon className="size-6 text-primary" aria-hidden="true" /><span className="text-xs text-muted-foreground">0{index + 1}</span></div>
            <div className="mt-16"><h3 className="font-display text-xl font-semibold text-foreground">{title}</h3><p className="mt-3 text-sm leading-6 text-muted-foreground">{detail}</p></div>
          </article>
        ))}
      </div>
    </section>
  );
}

function Experience() {
  const points = [
    "Experimenting with AI tools and agent workflows",
    "Building websites, applications, and automation",
    "Connecting content, campaigns, and company systems",
  ];
  return (
    <section id="experience" className="section-shell bg-secondary/40">
      <div className="grid gap-12 lg:grid-cols-[0.75fr_1.25fr] lg:gap-24">
        <SectionHeading number="03" label="Experience" title="Learn fast. Build clearly. Improve continuously." />
        <div className="self-end">
          <p className="max-w-2xl text-lg leading-8 text-muted-foreground">My experience is hands-on: learning through live tools, real workflows, and the discipline of turning a broad idea into a focused working system.</p>
          <ul className="mt-9 border-t border-border">
            {points.map((point) => <li key={point} className="flex items-center gap-3 border-b border-border py-5 text-foreground"><Check className="size-4 text-primary" />{point}</li>)}
          </ul>
        </div>
      </div>
    </section>
  );
}

function Oculus() {
  return (
    <section id="oculus" className="section-shell overflow-hidden">
      <SectionHeading number="04" label="Selected project" title="One focus. Oculus." />
      <div className="oculus-stage mt-14 min-h-[34rem]">
        <div className="oculus-mark" aria-hidden="true"><span>O</span></div>
        <div className="relative z-10 flex h-full min-h-[34rem] flex-col justify-between p-7 md:p-12">
          <div className="flex items-center justify-between text-xs uppercase text-muted-foreground"><span>Project / 001</span><span>Details available on request</span></div>
          <div className="max-w-2xl"><h3 className="font-display text-6xl font-semibold text-foreground md:text-8xl">Oculus</h3><div className="mt-8"><Button asChild size="lg"><a href={profile.whatsapp} target="_blank" rel="noreferrer"><MessageCircle /> Ask about Oculus</a></Button></div></div>
        </div>
      </div>
    </section>
  );
}

function Technologies() {
  return (
    <section id="skills" className="section-shell border-y border-border px-0">
      <div className="mx-auto max-w-7xl px-5 md:px-10"><SectionHeading number="05" label="Technology" title="A broad toolkit for connected work." /></div>
      <div className="mt-14 space-y-3 overflow-hidden" aria-label="100 technologies and skills">
        {technologyRows.map((row, index) => (
          <div key={row[0]} className="marquee-track" data-reverse={index % 2 === 1}>
            {[...row, ...row].map((technology, itemIndex) => <span key={`${technology}-${itemIndex}`} className="tech-chip"><Sparkles aria-hidden="true" />{technology}</span>)}
          </div>
        ))}
      </div>
    </section>
  );
}

function Contact() {
  return (
    <section id="contact" className="section-shell pb-10">
      <div className="contact-panel px-6 py-14 md:px-12 md:py-20">
        <p className="eyebrow">06 / Start a conversation</p>
        <h2 className="mt-7 max-w-5xl font-display text-5xl font-semibold leading-[1.03] text-foreground md:text-7xl">Have a problem AI could help solve?</h2>
        <div className="mt-12 flex flex-col gap-8 border-t border-border pt-8 md:flex-row md:items-end md:justify-between">
          <div><p className="text-sm text-muted-foreground">WhatsApp</p><a href={profile.whatsapp} target="_blank" rel="noreferrer" className="mt-2 block font-display text-2xl font-semibold text-foreground hover:text-primary">{profile.phone}</a></div>
          <div className="flex flex-wrap gap-3"><Button asChild size="lg"><a href={profile.whatsapp} target="_blank" rel="noreferrer"><MessageCircle /> Chat on WhatsApp</a></Button><Button asChild size="lg" variant="glass"><a href={profile.linkedin} target="_blank" rel="noreferrer"><Linkedin /> LinkedIn</a></Button></div>
        </div>
      </div>
      <footer className="flex flex-col gap-4 py-8 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between"><span>© 2026 Given Arori</span><ExternalLink href={profile.company}>Tripple AI Systems</ExternalLink></footer>
    </section>
  );
}

function useScrollMotion() {
  useEffect(() => {
    const els = Array.from(document.querySelectorAll<HTMLElement>("main section > *, .section-heading, main article, main li, .glass-panel"));
    els.forEach((el, i) => el.setAttribute("data-reveal", i % 2 ? "right" : "left"));
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.target.classList.toggle("revealed", e.isIntersecting)),
      { threshold: 0.12 },
    );
    els.forEach((el) => io.observe(el));
    const root = document.documentElement;
    let timer = 0;
    const onScroll = () => {
      root.classList.add("is-scrolling");
      window.clearTimeout(timer);
      timer = window.setTimeout(() => root.classList.remove("is-scrolling"), 180);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => { io.disconnect(); window.removeEventListener("scroll", onScroll); window.clearTimeout(timer); };
  }, []);
}

export function Portfolio() {
  useScrollMotion();
  return <main className="relative isolate"><StarField /><Header /><Hero /><About /><Services /><Experience /><Oculus /><Technologies /><Contact /></main>;
}
