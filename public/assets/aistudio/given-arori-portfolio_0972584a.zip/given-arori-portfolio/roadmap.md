# Roadmap

- [x] Define the clear-glass visual system and portfolio content model.
- [x] Build the single-page portfolio and exact contact links.
- [x] Add route metadata and focused content tests.
- [ ] Verify tests, build diagnostics, and desktop/mobile interactions.